<?php

class Utility{

	public $utility_id;
	public $utility_name;
}