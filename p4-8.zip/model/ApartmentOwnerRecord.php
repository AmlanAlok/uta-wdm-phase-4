<?php

class ApartmentOwnerRecord {

	public $building_name;
	public $apartment_number;
	public $first_name;
	public $last_name;		
	public $email_id;
	public $phone_number;
	public $joining_datetime;
}