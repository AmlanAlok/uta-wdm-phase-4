<?php

class SubdivisionUtilityTableRecord {

	public $buildingName;
	public $apartmentNumber;
	public $electricity;
	public $gas;
	public $water;
	public $total;
}