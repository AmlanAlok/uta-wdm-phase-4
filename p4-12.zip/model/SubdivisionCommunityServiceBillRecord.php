<?php

class SubdivisionCommunityServiceBillRecord{

	public $building_name;
	public $apartment_number;
	public $community_service_monthly_bill_amount;
	public $month;
	public $year;
	public $community_service_name;
}