<?php

class ApartmentDashboardData {

	public $monthNumbers;
	public $electricityMonthTotal;
	public $gasMonthTotal;
	public $waterMonthTotal;
	public $internetMonthTotal;
}