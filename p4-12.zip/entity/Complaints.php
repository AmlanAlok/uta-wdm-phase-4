<?php

class Complaints {
	public $complaint_id;
	public $message;
	public $status;
	public $message_datetime;
	public $month;
	public $year;
	public $apartments_apartment_id;
	public $buildings_building_id;
	public $subdivisions_subdivision_id;
	public $users_user_id;
}