<?php

class ApartmentCommunityServiceBill{

	public $apartment_community_service_bill_id;
	public $month;
	public $year;
	public $community_service_monthly_bill_amount;
	public $community_service_id;
	public $apartments_apartment_id;
	public $buildings_building_id;
	public $subdivisions_subdivision_id;
	public $users_user_id;
}