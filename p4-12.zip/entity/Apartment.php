<?php

class Apartment {

	public $apartment_id;
	public $apartment_number;
	public $occupancy_status;
	public $buildings_building_id;
	public $subdivisions_subdivision_id;
	public $users_user_id;

	// function __construct($apartment_number, $occupancy_status, $buildings_building_id, $subdivisions_subdivision_id, $users_user_id){

	// 	$this->apartment_number = $apartment_number;
	// 	$this->occupancy_status = $occupancy_status;
	// 	$this->buildings_building_id = $buildings_building_id;
	// 	$this->subdivisions_subdivision_id = $subdivisions_subdivision_id;
	// 	$this->users_user_id = $users_user_id;
	// }

}