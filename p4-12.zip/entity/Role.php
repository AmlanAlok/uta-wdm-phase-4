<?php

class Role{

	public $role_id;
	public $role_name;

	// function getRoleId(){
	// 	return $this->roleId;
	// }

	// function getRoleName(){
	// 	return $this->roleName;
	// }
}