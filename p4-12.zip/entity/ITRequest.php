<?php


class ITRequest {
	
	public $it_request_id;
	public $message;
	public $status;
	public $message_datetime;
	public $subdivisions_subdivision_id;

	// it_request_id;
	// message;
	// status;
	// message_datetime;
	// subdivisions_subdivision_id;
}