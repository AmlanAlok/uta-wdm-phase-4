<?php

class ApartmentUtilityBillRecord {

	public $utility_monthly_bill_amount;
	public $utility_name;
	public $service_provider_type;
} 