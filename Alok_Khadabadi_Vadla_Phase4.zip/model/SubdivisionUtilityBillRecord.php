<?php

class SubdivisionUtilityBillRecord {

	public $building_name;
	public $apartment_number;
	public $utility_monthly_bill_amount;
	public $month;
	public $year;
	public $utility_name;
	public $service_provider_type;
	// buildingName;
	// apartmentNumber;
	// electricity;
	// gas;
	// water;
}