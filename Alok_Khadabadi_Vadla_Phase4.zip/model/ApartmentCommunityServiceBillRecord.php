<?php

class ApartmentCommunityServiceBillRecord {

	public $community_service_monthly_bill_amount;
	public $community_service_name;
}