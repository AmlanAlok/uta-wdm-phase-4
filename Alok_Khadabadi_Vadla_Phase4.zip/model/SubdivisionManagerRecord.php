<?php

class SubdivisionManagerRecord {

	public $subdivision_name;
	public $first_name;
	public $last_name;		
	public $email_id;
	public $phone_number;
	public $joining_datetime;
}