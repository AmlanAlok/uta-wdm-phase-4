<?php

class SubdivisionDashboardData {

	public $monthNumbers;
	public $electricityMonthTotal;
	public $gasMonthTotal;
	public $waterMonthTotal;
}