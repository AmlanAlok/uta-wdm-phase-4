<?php

class ApartmentUtilityBill {

	public $apartment_utility_bill_id;
	public $month;
	public $year;
	public $utility_monthly_bill_amount;
	public $service_provider_type;
	public $utilities_utility_id;
	public $apartments_apartment_id;
	public $buildings_building_id;
	public $subdivisions_subdivision_id;
	public $users_user_id;
}