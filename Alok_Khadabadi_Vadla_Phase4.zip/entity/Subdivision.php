<?php

class Subdivision {

	public $subdivision_id;
	public $subdivision_name;
	public $users_user_id;
}