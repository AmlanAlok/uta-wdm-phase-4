<?php

class CommunityService {

	public $community_service_id;
	public $community_service_name;
}