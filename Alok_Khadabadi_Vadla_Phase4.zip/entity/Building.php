<?php

class Building {

	public $building_id;
	public $building_name;
	public $occupancy_status;
	public $subdivisions_subdivision_id;
	public $users_user_id;

}